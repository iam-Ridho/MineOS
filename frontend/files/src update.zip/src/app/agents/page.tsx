"use client";

import { useState } from "react";
import { useTelemetry } from "@/context/TelemetryContext";
import { CheckSquare, Zap } from "lucide-react";

function AgentCard({ agent }: { agent: any }) {
  const [showLogs, setShowLogs] = useState(true);

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case "running":
      case "active":
        return "bg-emerald-50 text-emerald-600 border-emerald-300";
      case "processing":
        return "bg-amber-50 text-amber-600 border-amber-300";
      case "idle":
        return "bg-slate-500/10 text-slate-500 border-slate-500/30";
      default:
        return "bg-slate-500/10 text-slate-500 border-slate-500/30";
    }
  };

  const getAgentLogColor = (agentName: string) => {
    const name = agentName.toLowerCase();
    if (name === "fleet") return "text-amber-600";
    if (name === "safety") return "text-emerald-600";
    if (name === "emission") return "text-blue-600";
    if (name === "reclamation") return "text-green-400";
    if (name === "system") return "text-slate-500";
    return "text-slate-500";
  };

  return (
    <div className="bg-white border border-slate-200 rounded-xl overflow-hidden hover:border-blue-500/20 transition-all shadow-lg flex flex-col h-full">
      {/* Header */}
      <div className="flex justify-between items-center p-5 border-b border-slate-200/50">
        <h3 className="text-slate-900 font-bold text-sm font-sans">{agent.name}</h3>
        <span className={`text-[10px] font-bold tracking-wider px-2.5 py-1 rounded border ${getStatusColor(agent.status)}`}>
          {agent.status.toUpperCase()}
        </span>
      </div>

      {/* Task Section */}
      <div className="px-5 py-4 border-b border-slate-200/50 flex-1">
        <p className="text-xs text-slate-500 font-mono leading-relaxed">{agent.currentTask}</p>
      </div>

      {/* Metrics Section */}
      <div className="px-5 py-3 border-b border-slate-200/50 space-y-2">
        <div className="flex justify-between items-center">
          <span className="text-xs text-slate-500 font-mono uppercase tracking-widest">{agent.attributeLabel1}</span>
          <span className="text-xs font-bold text-blue-600 font-mono">{agent.attributeValue1}</span>
        </div>
        {agent.attributeLabel2 && (
          <div className="flex justify-between items-center">
            <span className="text-xs text-slate-500 font-mono uppercase tracking-widest">{agent.attributeLabel2}</span>
            <span className="text-xs font-bold text-blue-600 font-mono">{agent.attributeValue2}</span>
          </div>
        )}
      </div>

      {/* Logs Section */}
      <div className="px-5 py-3 border-b border-slate-200/50">
        <div className="text-xs text-slate-500 font-mono uppercase tracking-widest mb-2 flex items-center gap-1.5">
          LOG KOMUNIKASI
        </div>
        <div className="space-y-1">
          {agent.logs && agent.logs.slice(0, 3).map((log: any, idx: number) => (
            <div key={log.id || idx} className="flex items-start gap-2">
              <span className={`text-[10px] font-bold shrink-0 ${getAgentLogColor(log.agent)}`}>
                [{log.agent.toUpperCase()}]
              </span>
              <span className="text-[10px] text-slate-500 line-clamp-1">{log.message}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Bottom Metrics */}
      <div className="px-5 py-3 border-b border-slate-200/50 flex justify-between text-[10px] font-mono text-slate-500">
        <span>TASK: {agent.taskId}</span>
        <span className="text-blue-600 font-bold">{agent.confidence.toFixed(1)}% Confidence</span>
      </div>

      {/* Action Buttons */}
      <div className="px-5 py-3 flex gap-2">
        <button className="flex-1 py-1.5 px-2 text-[10px] font-mono font-bold uppercase border border-slate-300 rounded text-slate-500 hover:text-slate-900 hover:border-slate-300 transition-colors flex items-center justify-center gap-1">
          <CheckSquare size={12} /> VERIFY LOGIC
        </button>
        <button className="flex-1 py-1.5 px-2 text-[10px] font-mono font-bold uppercase border border-blue-300 bg-blue-50/50 rounded text-blue-600 hover:bg-blue-50 transition-colors flex items-center justify-center gap-1">
          <Zap size={12} /> OVERRIDE MODE
        </button>
      </div>
    </div>
  );
}

export default function AgentMonitorPage() {
  const { agents } = useTelemetry();

  return (
    <div className="flex-1 p-8 overflow-y-auto h-[calc(100vh-4rem)] bg-slate-50 relative">
      {/* Header */}
      <div className="mb-8">
        <h1 className="font-sans text-xl font-bold text-slate-900 flex items-center gap-3 mb-2">
          <span className="w-1.5 h-7 bg-cyan-500 rounded-sm"></span>
          LANGGRAPH ORCHESTRATION
        </h1>
        <p className="text-slate-500 font-mono text-xs">
          Sistem multi-agent otonom untuk optimasi operasional pit tambang
        </p>
      </div>

      {/* Agent Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {agents && agents.map((agent) => (
          <AgentCard key={agent.id} agent={agent} />
        ))}
      </div>

      {/* Dispatch Console */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-2xl">
        <h2 className="font-sans text-sm font-bold uppercase text-slate-900 flex items-center gap-2 mb-4">
          <span className="w-1 h-5 bg-cyan-500 rounded-sm"></span>
          Interactive Dispatch Override console
        </h2>
        <p className="text-xs text-slate-500 font-mono mb-4">
          Inject manual logs or override instruction payloads otonomously into specific agent telemetry stream queues.
        </p>
        
        <div className="flex gap-3">
          <div className="flex-1">
            <label className="text-xs text-slate-500 font-mono uppercase tracking-widest mb-2 block">
              SELECT AGENT MODE
            </label>
            <select className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded text-xs text-slate-900 font-mono focus:outline-none focus:border-blue-500/40">
              <option>Fleet Agent</option>
              <option>Safety Agent</option>
              <option>Emission Agent</option>
              <option>Reclamation</option>
            </select>
          </div>
          <div className="flex-1">
            <label className="text-xs text-slate-500 font-mono uppercase tracking-widest mb-2 block">
              INSTRUCTION PAYLOAD MESSAGE
            </label>
            <input
              type="text"
              placeholder="e.g. Reroute dispatch to Zone G, trigger active ventilation system..."
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded text-xs text-slate-900 font-mono placeholder-slate-600 focus:outline-none focus:border-blue-500/40"
            />
          </div>
          <div className="pt-6">
            <button className="px-6 py-2 bg-cyan-500 hover:bg-cyan-600 text-slate-900 text-xs font-bold rounded flex items-center gap-2 transition-colors">
              <Zap size={14} /> INJECT PAYLOAD
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}