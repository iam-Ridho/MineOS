// src/app/llm-report/page.tsx
"use client";

import { FileText, Download, RefreshCw, Brain } from "lucide-react";

const reportData = [
  { label: "Model", value: "MineOS-LLM v2.1" },
  { label: "Context Window", value: "128K tokens" },
  { label: "Inference Mode", value: "Quantized INT8" },
  { label: "Avg Response Time", value: "340ms" },
  { label: "Total Requests (24h)", value: "1.842" },
  { label: "Success Rate", value: "99.7%" },
];

const recentLogs = [
  { time: "16:05", agent: "Fleet Agent",      prompt: "Optimize route for Truck-04 via Zone Alpha", tokens: 320 },
  { time: "15:48", agent: "Safety Agent",     prompt: "Evaluate blast zone clearance Sector 4",     tokens: 210 },
  { time: "15:30", agent: "Emission Agent",   prompt: "Carbon offset calculation Q3 fleet",         tokens: 450 },
  { time: "14:55", agent: "Reclamation",      prompt: "Revegetation plan update Block D-12",        tokens: 180 },
  { time: "14:20", agent: "Fleet Agent",      prompt: "Dispatch reroute advisory Crusher bypass",   tokens: 265 },
];

export default function LLMReportPage() {
  return (
    <div className="flex-1 p-6 overflow-y-auto h-[calc(100vh-4rem)] bg-slate-50 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-slate-900 font-semibold flex items-center gap-2">
            <span className="w-1.5 h-6 bg-cyan-500 rounded-sm"></span>
            LLM Inference Report
          </h2>
          <p className="text-slate-500 text-xs mt-0.5 font-mono">Statistik inferensi model — Kideco, Batu Sopang, Paser, Kaltim</p>
        </div>
        <div className="flex gap-2">
          <button className="flex items-center gap-2 text-xs font-mono text-slate-500 hover:text-slate-900 bg-slate-100/500 border border-slate-200 px-3 py-1.5 rounded-lg transition-colors">
            <RefreshCw size={12} /> Refresh
          </button>
          <button className="flex items-center gap-2 text-xs font-mono text-slate-500 hover:text-slate-900 bg-slate-100/500 border border-slate-200 px-3 py-1.5 rounded-lg transition-colors">
            <Download size={12} /> Export CSV
          </button>
        </div>
      </div>

      {/* Model Stats */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        {reportData.map(({ label, value }) => (
          <div key={label} className="bg-white p-4 rounded-xl border border-slate-200 hover:border-blue-500/20 transition-all">
            <p className="text-slate-500 text-[10px] font-mono uppercase tracking-widest">{label}</p>
            <p className="text-slate-900 font-bold text-sm mt-1">{value}</p>
          </div>
        ))}
      </div>

      {/* Recent Inference Log */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-200 flex items-center gap-2">
          <Brain size={14} className="text-blue-600" />
          <h3 className="text-slate-900 font-semibold text-sm">Recent Inference Log</h3>
        </div>
        <div className="divide-y divide-slate-800">
          {recentLogs.map((log, i) => (
            <div key={i} className="flex items-center px-5 py-3 hover:bg-slate-100/50 transition-colors">
              <span className="text-slate-500 font-mono text-xs w-14">{log.time}</span>
              <span className="text-blue-600 font-mono text-xs w-36">{log.agent}</span>
              <span className="text-slate-700 text-xs flex-1 truncate">{log.prompt}</span>
              <span className="text-slate-500 font-mono text-xs ml-4">{log.tokens} tok</span>
            </div>
          ))}
        </div>
        <div className="px-5 py-3 border-t border-slate-200">
          <p className="text-xs text-slate-600 font-mono">Menampilkan 5 log terbaru dari hari ini</p>
        </div>
      </div>

    </div>
  );
}
