"use client";

import { useState } from "react";
import { useRealtimeData } from "@/hooks/useRealtimeData";
import {
  Activity,
  AlertTriangle,
  RefreshCw,
  WifiOff,
  Database,
  Server,
  Bot,
} from "lucide-react";

export default function AgentMonitorPage() {
  const { agents, decisions, health, loading, error, lastUpdate, refresh } = useRealtimeData(3000);
  const [selectedAgent, setSelectedAgent] = useState<string | null>(null);

  const selectedAgentData = agents.find(a => a.id === selectedAgent);

  return (
    <div className="flex-1 h-[calc(100vh-4rem)] overflow-y-auto bg-slate-50">
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="font-sans text-xl font-bold text-slate-900 flex items-center gap-3">
              <span className="w-1.5 h-7 bg-cyan-500 rounded-sm" />
              Agent Monitor
            </h1>
            <p className="text-slate-500 font-mono text-xs mt-1">
              Real-time monitoring dari Backend Ridho & Supabase
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 text-xs">
              <span className={`flex items-center gap-1 px-2 py-1 rounded border font-mono text-[10px] font-bold uppercase ${health.backend ? "bg-emerald-50 border-emerald-200 text-emerald-600" : "bg-red-50 border-red-200 text-red-600"}`}>
                <Server className="w-3 h-3" />
                Backend {health.backend ? "ONLINE" : "OFFLINE"}
              </span>
              <span className={`flex items-center gap-1 px-2 py-1 rounded border font-mono text-[10px] font-bold uppercase ${health.supabase ? "bg-emerald-50 border-emerald-200 text-emerald-600" : "bg-red-50 border-red-200 text-red-600"}`}>
                <Database className="w-3 h-3" />
                Supabase {health.supabase ? "ONLINE" : "OFFLINE"}
              </span>
            </div>

            <button
              onClick={refresh}
              disabled={loading}
              className="flex items-center gap-2 px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-slate-600 hover:text-blue-600 hover:border-blue-300 transition-all text-[10px] font-mono font-bold uppercase disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? "animate-spin" : ""}`} />
              Refresh
            </button>
          </div>
        </div>

        {/* Last Update */}
        {lastUpdate && (
          <div className="text-xs text-slate-400 font-mono">
            Last sync: {lastUpdate.toLocaleTimeString()}
          </div>
        )}

        {/* Error */}
        {error && (
          <div className="p-3 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-600 text-sm">
            <AlertTriangle className="w-4 h-4" />
            {error}
          </div>
        )}

        {/* Loading State */}
        {loading && agents.length === 0 && (
          <div className="flex items-center justify-center h-64 text-slate-400">
            <RefreshCw className="w-8 h-8 animate-spin mr-3" />
            Menghubungkan ke backend & Supabase...
          </div>
        )}

        {/* No Data */}
        {!loading && agents.length === 0 && (
          <div className="flex flex-col items-center justify-center h-64 text-slate-400">
            <WifiOff className="w-12 h-12 mb-3 opacity-50" />
            <p>Tidak ada data agent dari backend atau Supabase</p>
            <p className="text-sm mt-1">Pastikan backend Ridho (10.10.14.24:8000) berjalan</p>
          </div>
        )}

        {/* Main Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Agent List */}
          <div className="lg:col-span-2 space-y-3">
            {agents.map((agent) => {
              const statusConfig = {
                running: { dot: "bg-emerald-500", label: "RUNNING", animate: true },
                active: { dot: "bg-emerald-500", label: "ACTIVE", animate: true },
                processing: { dot: "bg-amber-500", label: "PROCESSING", animate: true },
                idle: { dot: "bg-slate-400", label: "IDLE", animate: false },
                error: { dot: "bg-red-500", label: "ERROR", animate: true },
                offline: { dot: "bg-gray-500", label: "OFFLINE", animate: false },
              }[agent.status] || { dot: "bg-slate-400", label: "IDLE", animate: false };

              return (
                <div
                  key={agent.id}
                  onClick={() => setSelectedAgent(agent.id)}
                  className={`bg-white rounded-xl border p-4 cursor-pointer transition-all hover:shadow-md ${
                    selectedAgent === agent.id
                      ? "border-cyan-500 shadow-lg"
                      : "border-slate-200 hover:border-blue-300"
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-3">
                      <span className={`w-2.5 h-2.5 rounded-full ${statusConfig.dot} ${statusConfig.animate ? "animate-pulse" : ""}`} />
                      <div>
                        <h3 className="font-sans text-sm font-bold text-slate-900">{agent.name}</h3>
                        <p className="text-[10px] text-slate-500 font-mono uppercase">{agent.domain || "general"}</p>
                      </div>
                    </div>
                    <span className={`px-2 py-0.5 rounded border text-[9px] font-mono font-bold uppercase ${
                      agent.status === "active" || agent.status === "running" ? "border-emerald-300 bg-emerald-50 text-emerald-600" :
                      agent.status === "idle" ? "border-amber-300 bg-amber-50 text-amber-600" :
                      agent.status === "error" ? "border-red-300 bg-red-50 text-red-600" :
                      "border-slate-300 bg-slate-50 text-slate-600"
                    }`}>
                      {statusConfig.label}
                    </span>
                  </div>

                  {agent.currentTask && (
                    <p className="text-xs text-slate-600 font-sans leading-relaxed line-clamp-2">
                      {agent.currentTask}
                    </p>
                  )}

                  {agent.confidence !== undefined && (
                    <div className="mt-3">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-[9px] text-slate-400 font-mono">Confidence</span>
                        <span className="text-[10px] font-bold text-blue-600 font-mono">{Math.round(agent.confidence * 100)}%</span>
                      </div>
                      <div className="w-full bg-slate-200 h-1 rounded-full overflow-hidden">
                        <div className="h-full bg-cyan-500 rounded-full transition-all" style={{ width: `${Math.round(agent.confidence * 100)}%` }} />
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Detail Panel */}
          <div className="lg:col-span-1 space-y-4">
            {selectedAgentData ? (
              <div className="sticky top-6 bg-white rounded-xl border border-slate-200 p-5 shadow-lg">
                <h3 className="font-sans text-base font-bold text-slate-900 mb-4">{selectedAgentData.name}</h3>

                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-slate-500 font-mono text-[10px] uppercase">ID</span>
                    <span className="font-mono text-slate-900 text-xs">{selectedAgentData.id}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500 font-mono text-[10px] uppercase">Status</span>
                    <span className="capitalize text-slate-900 text-xs">{selectedAgentData.status}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500 font-mono text-[10px] uppercase">Domain</span>
                    <span className="text-slate-900 text-xs">{selectedAgentData.domain || "-"}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500 font-mono text-[10px] uppercase">Confidence</span>
                    <span className="text-slate-900 text-xs">{selectedAgentData.confidence ? `${Math.round(selectedAgentData.confidence * 100)}%` : "-"}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500 font-mono text-[10px] uppercase">Last Seen</span>
                    <span className="text-slate-900 text-xs">{selectedAgentData.lastSeen ? new Date(selectedAgentData.lastSeen).toLocaleString() : "-"}</span>
                  </div>
                </div>

                {selectedAgentData.currentTask && (
                  <div className="mt-4 p-3 bg-slate-50 rounded-lg border border-slate-200">
                    <span className="text-slate-400 text-[9px] font-mono uppercase">Current Task</span>
                    <p className="mt-1 text-xs text-slate-700 font-sans leading-relaxed">{selectedAgentData.currentTask}</p>
                  </div>
                )}
              </div>
            ) : (
              <div className="sticky top-6 bg-white rounded-xl border border-slate-200 p-5 text-center text-slate-400 shadow-lg">
                <Bot className="w-8 h-8 mx-auto mb-2 opacity-30" />
                <p className="font-mono text-xs">Pilih agent untuk melihat detail</p>
              </div>
            )}

            {/* Recent AI Decisions */}
            <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-lg">
              <h4 className="font-mono text-[10px] font-bold uppercase tracking-widest text-slate-900 flex items-center gap-2 mb-4">
                <Database className="w-4 h-4 text-blue-600" />
                Recent AI Decisions
              </h4>
              <div className="space-y-3 max-h-64 overflow-y-auto">
                {decisions.slice(0, 10).map((d, i) => (
                  <div key={i} className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                    <div className="flex items-center gap-1.5 mb-1.5">
                      <span className={`w-2 h-2 rounded-full ${
                        d.priority_level === "critical" ? "bg-red-500" :
                        d.priority_level === "high" ? "bg-orange-500" :
                        d.priority_level === "medium" ? "bg-amber-500" : "bg-emerald-500"
                      }`} />
                      <span className="text-[9px] text-slate-500 font-mono uppercase">{d.priority_level}</span>
                      <span className="ml-auto text-[9px] text-slate-400 font-mono">{d.source || "unknown"}</span>
                    </div>
                    <p className="text-xs text-slate-700 font-sans leading-relaxed line-clamp-2">{d.decision_text}</p>
                  </div>
                ))}
                {decisions.length === 0 && (
                  <p className="text-slate-400 text-center py-4 font-mono text-xs">No decisions yet</p>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}