// src/hooks/useRealtimeData.ts
// Hook untuk data real-time dari backend + Supabase

import { useState, useEffect, useCallback, useRef } from "react";
import {
  getAgentsStatus,
  getVehiclesPositions,
  getEmissionsToday,
  getAIDecisions,
  subscribeToAIDecisions,
  checkBackendHealth,
  type AgentStatus,
  type VehiclePosition,
  type EmissionData,
  type AIDecision,
} from "@/lib/api/backend";

interface RealtimeDataState {
  agents: AgentStatus[];
  vehicles: VehiclePosition[];
  emissions: EmissionData | null;
  decisions: AIDecision[];
  health: { backend: boolean; supabase: boolean };
  loading: boolean;
  error: string | null;
  lastUpdate: Date | null;
}

export function useRealtimeData(pollInterval: number = 5000) {
  const [state, setState] = useState<RealtimeDataState>({
    agents: [],
    vehicles: [],
    emissions: null,
    decisions: [],
    health: { backend: false, supabase: false },
    loading: true,
    error: null,
    lastUpdate: null,
  });

  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  const fetchAll = useCallback(async () => {
    setState(prev => ({ ...prev, loading: true, error: null }));

    try {
      const [agents, vehicles, emissions, decisions, health] = await Promise.allSettled([
        getAgentsStatus(),
        getVehiclesPositions(),
        getEmissionsToday(),
        getAIDecisions(50),
        checkBackendHealth(),
      ]);

      setState(prev => ({
        ...prev,
        agents: agents.status === "fulfilled" ? agents.value : prev.agents,
        vehicles: vehicles.status === "fulfilled" ? vehicles.value : prev.vehicles,
        emissions: emissions.status === "fulfilled" ? emissions.value : prev.emissions,
        decisions: decisions.status === "fulfilled" ? decisions.value : prev.decisions,
        health: health.status === "fulfilled" ? health.value : prev.health,
        loading: false,
        lastUpdate: new Date(),
      }));
    } catch (err) {
      setState(prev => ({
        ...prev,
        loading: false,
        error: err instanceof Error ? err.message : "Unknown error",
      }));
    }
  }, []);

  // Initial fetch + polling
  useEffect(() => {
    fetchAll();
    intervalRef.current = setInterval(fetchAll, pollInterval);

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [fetchAll, pollInterval]);

  // Realtime subscription untuk AI decisions
  useEffect(() => {
    const unsubscribe = subscribeToAIDecisions((newDecision) => {
      setState(prev => ({
        ...prev,
        decisions: [newDecision, ...prev.decisions].slice(0, 100),
        lastUpdate: new Date(),
      }));
    });

    return unsubscribe;
  }, []);

  return {
    ...state,
    refresh: fetchAll,
  };
}