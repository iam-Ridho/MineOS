// src/lib/api/backend.ts
// Dual source: Backend Ridho (primary) + Supabase (fallback/realtime)
// FIXED: Kompatibel dengan dashboard/page.tsx yang sudah ada

import { createClient } from "@supabase/supabase-js";

// ─── Supabase Client ─────────────────────────────────────────
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || "";
const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || "";
export const supabase = createClient(supabaseUrl, supabaseKey);

// ─── API Base ────────────────────────────────────────────────
const API_BASE = "";

// ─── Types ───────────────────────────────────────────────────

// AgentStatus — untuk individual agent
export interface AgentStatus {
  id: string;
  name: string;
  status: "active" | "idle" | "error" | "offline" | "running" | "processing";
  currentTask?: string;
  confidence?: number;
  metrics?: {
    tasksCompleted: number;
    successRate: number;
    avgResponseTime: number;
  };
  domain?: string;
  lastSeen?: string;
}

// 🔥 FIXED: AgentStatusResponse = AgentStatus (alias untuk kompatibilitas)
export type AgentStatusResponse = AgentStatus;

// Vehicle — untuk individual vehicle (field lengkap untuk dashboard)
export interface VehicleLiveResponse {
  id: string;
  vehicleId?: string;
  name: string;
  lat: number;
  lng?: number;
  lon: number;
  speed: number;
  status: string;
  fuel: number;
  fuel_level?: number;
  zone: string;
  operator: string;
  load_weight: number;
  heading: number;
  timestamp: string;
}

// 🔥 EXPORT UNTUK HOOK — alias untuk kompatibilitas
export type VehiclePosition = VehicleLiveResponse;

// EmissionData
export interface EmissionData {
  co2: number;
  nox: number;
  pm25: number;
  fuelEfficiency: number;
  timestamp: string;
  fleet_total_24h?: number;
  total_vehicles?: number;
  avg_emission?: number;
}

export interface AIDecision {
  id: string;
  decision_text: string;
  triggered_agents: string[];
  priority_level: "low" | "medium" | "high" | "critical";
  timestamp: string;
  source?: "backend" | "supabase";
}

// 🔥 STATUS CONFIG — FIXED: Gunakan 'as const' agar TypeScript tahu semua key
export const AGENT_STATUS_CONFIG = {
  running: { dot: "bg-green-400", label: "RUNNING", animate: true },
  active: { dot: "bg-green-400", label: "ACTIVE", animate: true },
  processing: { dot: "bg-blue-400", label: "PROCESSING", animate: true },
  idle: { dot: "bg-yellow-400", label: "IDLE", animate: false },
  error: { dot: "bg-red-400", label: "ERROR", animate: false },
  offline: { dot: "bg-gray-400", label: "OFFLINE", animate: false },
} as const;

// 🔥 TYPE HELPER — untuk akses AGENT_STATUS_CONFIG[status]
export type AgentStatusKey = keyof typeof AGENT_STATUS_CONFIG;

// ─── Helper: Fetch with timeout ──────────────────────────────
async function fetchWithTimeout(
  url: string,
  options: RequestInit = {},
  timeoutMs: number = 5000
): Promise<Response> {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const response = await fetch(url, {
      ...options,
      signal: controller.signal,
    });
    clearTimeout(timeoutId);
    return response;
  } catch (error) {
    clearTimeout(timeoutId);
    throw error;
  }
}

// ─── Fetch from Backend Ridho ────────────────────────────────
async function fetchFromBackend<T>(endpoint: string): Promise<T | null> {
  try {
    const response = await fetchWithTimeout(`${API_BASE}${endpoint}`);
    if (!response.ok) {
      console.warn(`Backend error ${response.status}: ${endpoint}`);
      return null;
    }
    return await response.json();
  } catch (error) {
    console.warn("Backend unreachable:", endpoint, error);
    return null;
  }
}

// ─── Fetch from Supabase ─────────────────────────────────────
async function fetchFromSupabase<T>(
  table: string,
  limit: number = 50
): Promise<T[] | null> {
  try {
    const { data, error } = await supabase
      .from(table)
      .select("*")
      .order("timestamp", { ascending: false })
      .limit(limit);

    if (error) {
      console.warn("Supabase error:", table, error);
      return null;
    }
    return data as T[];
  } catch (error) {
    console.warn("Supabase unreachable:", table, error);
    return null;
  }
}

// ─── Dual Source Fetch: Agents ───────────────────────────────
export async function getAgentsStatus(): Promise<AgentStatus[]> {
  const backendData = await fetchFromBackend<AgentStatus[]>("/api/agents/status");
  if (backendData && backendData.length > 0) {
    console.log("✅ Agents from backend Ridho:", backendData.length);
    return backendData;
  }

  const supabaseData = await fetchFromSupabase<AIDecision>("ai_decisions", 100);
  if (supabaseData && supabaseData.length > 0) {
    console.log("✅ Agents from Supabase fallback:", supabaseData.length);
    const agentMap = new Map<string, AgentStatus>();
    supabaseData.forEach((decision) => {
      decision.triggered_agents?.forEach((agentName) => {
        if (!agentMap.has(agentName)) {
          agentMap.set(agentName, {
            id: `agent-${agentName.toLowerCase().replace(/\s+/g, "-")}`,
            name: agentName,
            status: "active",
            currentTask: decision.decision_text,
            confidence: 0.85,
            domain: "general",
            lastSeen: decision.timestamp,
          });
        }
      });
    });
    return Array.from(agentMap.values());
  }

  console.warn("⚠️ No agents data from any source");
  return [];
}

// 🔥 FUNGSI UNTUK DASHBOARD — Return AgentStatusResponse[] (alias AgentStatus[])
export async function getAgentStatus(): Promise<AgentStatusResponse[]> {
  return await getAgentsStatus();
}

// ─── Dual Source Fetch: Vehicles ─────────────────────────────
export async function getVehiclesPositions(): Promise<VehicleLiveResponse[]> {
  const backendData = await fetchFromBackend<any[]>("/api/vehicles/positions");
  if (backendData && backendData.length > 0) {
    return backendData.map(v => ({
      id: v.id || v.vehicleId || "unknown",
      name: v.name || v.vehicleId || "Unknown Vehicle",
      lat: v.lat || 0,
      lon: v.lon || v.lng || 0,
      speed: v.speed || 0,
      status: v.status || "unknown",
      fuel: v.fuel || v.fuel_level || 0,
      zone: v.zone || "Unknown",
      operator: v.operator || "Unknown",
      load_weight: v.load_weight || 0,
      heading: v.heading || 0,
      timestamp: v.timestamp || new Date().toISOString(),
    }));
  }

  const supabaseData = await fetchFromSupabase<any>("vehicles", 100);
  if (supabaseData) {
    return supabaseData.map(v => ({
      id: v.id || v.vehicleId || "unknown",
      name: v.name || v.vehicleId || "Unknown Vehicle",
      lat: v.lat || 0,
      lon: v.lon || v.lng || 0,
      speed: v.speed || 0,
      status: v.status || "unknown",
      fuel: v.fuel || v.fuel_level || 0,
      zone: v.zone || "Unknown",
      operator: v.operator || "Unknown",
      load_weight: v.load_weight || 0,
      heading: v.heading || 0,
      timestamp: v.timestamp || new Date().toISOString(),
    }));
  }

  return [];
}

// 🔥 FUNGSI UNTUK DASHBOARD — Return VehicleLiveResponse[] (individual vehicles)
export async function getVehiclesLive(): Promise<VehicleLiveResponse[]> {
  return await getVehiclesPositions();
}

// ─── Dual Source Fetch: Emissions ────────────────────────────
export async function getEmissionsToday(): Promise<EmissionData | null> {
  const backendData = await fetchFromBackend<EmissionData>("/api/emissions/today");
  if (backendData) return backendData;

  const supabaseData = await fetchFromSupabase<{ co2: number; nox: number; pm25: number; fleet_total_24h?: number }>("emissions", 1);
  if (supabaseData && supabaseData.length > 0) {
    return {
      ...supabaseData[0],
      fuelEfficiency: 0,
      timestamp: new Date().toISOString(),
    };
  }

  return null;
}

// ─── Dual Source Fetch: AI Decisions ─────────────────────────
export async function getAIDecisions(limit: number = 50): Promise<AIDecision[]> {
  const backendData = await fetchFromBackend<AIDecision[]>(`/api/ai/decisions?limit=${limit}`);
  if (backendData && backendData.length > 0) {
    return backendData.map(d => ({ ...d, source: "backend" as const }));
  }

  const supabaseData = await fetchFromSupabase<AIDecision>("ai_decisions", limit);
  if (supabaseData) {
    return supabaseData.map(d => ({ ...d, source: "supabase" as const }));
  }

  return [];
}

// ─── Realtime Subscription: Supabase ─────────────────────────
export function subscribeToAIDecisions(
  callback: (decision: AIDecision) => void
) {
  const subscription = supabase
    .channel("ai_decisions_realtime")
    .on(
      "postgres_changes",
      {
        event: "INSERT",
        schema: "public",
        table: "ai_decisions",
      },
      (payload) => {
        console.log("🔔 New AI decision from Supabase realtime:", payload.new);
        callback(payload.new as AIDecision);
      }
    )
    .subscribe();

  return () => {
    subscription.unsubscribe();
  };
}

// ─── Health Check ────────────────────────────────────────────
export async function checkBackendHealth(): Promise<{
  backend: boolean;
  supabase: boolean;
}> {
  const [backendOk, supabaseOk] = await Promise.allSettled([
    fetchWithTimeout(`${API_BASE}/api/health`).then(r => r.ok),
    supabase.from("ai_decisions").select("id", { count: "exact", head: true }).then(r => !r.error),
  ]);

  return {
    backend: backendOk.status === "fulfilled" && backendOk.value,
    supabase: supabaseOk.status === "fulfilled" && supabaseOk.value,
  };
}

// ─── WebSocket Connection Status ─────────────────────────────
export function getConnectionStatus(): "online" | "degraded" | "offline" {
  if (typeof navigator !== "undefined" && !navigator.onLine) {
    return "offline";
  }
  return "online";
}