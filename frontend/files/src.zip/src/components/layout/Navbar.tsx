"use client";

import { useState, useEffect } from "react";
import { Bell, X, Clock, Compass, PanelLeft, PanelLeftClose } from "lucide-react";

const notifications = [
  { id: 1, type: "error",   title: "Drill Unit Gamma — ERROR",    desc: "Baterai kritis 23%, segera cek.",           time: "2 mnt lalu" },
  { id: 2, type: "warning", title: "Produksi di bawah target",    desc: "Produksi hari ini 4.820 ton, target 5.000.", time: "15 mnt lalu" },
  { id: 3, type: "info",    title: "Haul Truck Beta — IDLE",      desc: "Tidak ada aktivitas selama 30 menit.",      time: "30 mnt lalu" },
];

const typeStyle = {
  error:   "bg-red-500",
  warning: "bg-amber-500",
  info:    "bg-blue-500",
};

interface NavbarProps {
  onToggleSidebar: () => void;
  sidebarOpen: boolean;
}

export default function Navbar({ onToggleSidebar, sidebarOpen }: NavbarProps) {
  const [time, setTime] = useState<string | null>(null); // null = tidak render di server
  const [openNotif, setOpenNotif] = useState(false);
  const [dismissed, setDismissed] = useState<number[]>([]);

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const h  = String(now.getHours()).padStart(2, "0");
      const m  = String(now.getMinutes()).padStart(2, "0");
      const s  = String(now.getSeconds()).padStart(2, "0");
      setTime(`${h}:${m}:${s}`);
    };
    updateTime(); // Set langsung saat mount
    const interval = setInterval(updateTime, 1000); // Update tiap 1 detik
    return () => clearInterval(interval);
  }, []);

  const active = notifications.filter((n) => !dismissed.includes(n.id));

  return (
    <header className="fixed top-0 left-0 right-0 z-50 flex justify-between items-center px-4 bg-white/80 backdrop-blur-md border-b border-slate-200 h-16 w-full select-none">
      {/* Kiri: Toggle + Logo & Judul */}
      <div className="flex items-center gap-3">
        <button
          onClick={onToggleSidebar}
          className="w-9 h-9 rounded-lg bg-slate-100 hover:bg-blue-50 border border-slate-200 hover:border-blue-200 flex items-center justify-center text-slate-500 hover:text-blue-600 transition-all duration-200"
          title={sidebarOpen ? "Sembunyikan sidebar" : "Tampilkan sidebar"}
        >
          {sidebarOpen ? <PanelLeftClose size={18} /> : <PanelLeft size={18} />}
        </button>

        <div className="w-px h-6 bg-slate-200" />

        <div className="flex items-center gap-4">
          <div className="w-9 h-9 bg-blue-50 rounded-md border border-blue-200 flex items-center justify-center shadow-sm">
            <Compass className="w-5 h-5 text-blue-600" />
          </div>
          <div>
            <h1 className="text-sm font-bold tracking-widest uppercase text-slate-800 font-sans flex items-center gap-2">
              <span className="text-slate-500">MineOS</span>
            </h1>
          </div>
        </div>
      </div>

      {/* Kanan: Jam + Notifikasi */}
      <div className="flex items-center gap-4">
        <div className="h-4 w-px bg-slate-200 hidden md:block" />

        {/* Jam — hanya render di client */}
        <div className="flex items-center gap-2 text-slate-500 font-mono text-[11px]">
          <Clock className="w-3.5 h-3.5 text-blue-500" />
          <span className="tracking-widest">{time ?? "--:--:--"}</span>
        </div>

        <div className="h-4 w-px bg-slate-200" />

        {/* Notifikasi */}
        <div className="relative">
          <button
            onClick={() => setOpenNotif(!openNotif)}
            className="relative text-slate-500 hover:text-slate-800 transition-colors"
          >
            <Bell size={16} />
            {active.length > 0 && (
              <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-amber-500 rounded-full text-[9px] font-bold text-slate-900 flex items-center justify-center">
                {active.length}
              </span>
            )}
          </button>

          {openNotif && (
            <div className="absolute right-0 top-8 w-80 bg-white border border-slate-200 rounded-xl shadow-xl overflow-hidden">
              <div className="px-4 py-3 border-b border-slate-200 flex items-center justify-between">
                <span className="text-slate-800 text-sm font-semibold">Notifikasi</span>
                <span className="text-xs text-slate-500 font-mono">{active.length} baru</span>
              </div>
              {active.length === 0 ? (
                <div className="px-4 py-6 text-center text-slate-500 text-sm">Tidak ada notifikasi</div>
              ) : (
                <div className="divide-y divide-slate-100">
                  {active.map((n) => (
                    <div key={n.id} className="flex gap-3 px-4 py-3 hover:bg-slate-50 transition-colors">
                      <div className={`w-2 h-2 rounded-full mt-1.5 shrink-0 ${typeStyle[n.type as keyof typeof typeStyle]}`} />
                      <div className="flex-1 min-w-0">
                        <p className="text-slate-800 text-xs font-medium">{n.title}</p>
                        <p className="text-slate-500 text-xs mt-0.5">{n.desc}</p>
                        <p className="text-slate-500 text-xs mt-1 font-mono">{n.time}</p>
                      </div>
                      <button
                        onClick={() => setDismissed([...dismissed, n.id])}
                        className="text-slate-500 hover:text-slate-600 shrink-0"
                      >
                        <X size={12} />
                      </button>
                    </div>
                  ))}
                </div>
              )}
              <div className="px-4 py-2.5 border-t border-slate-200">
                <button
                  onClick={() => setDismissed(notifications.map((n) => n.id))}
                  className="text-xs text-slate-500 hover:text-slate-800 transition-colors"
                >
                  Hapus semua
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}